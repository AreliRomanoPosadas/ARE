multiplicanueve y = y*9 
